package SERVER;

/**
 *
 * @author Richard Sastraputera
 */
import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChatServer {
    private static final int PORT = 12345; // Port yang digunakan untuk server

    public static void main(String[] args) {
        ExecutorService pool = Executors.newFixedThreadPool(10); // Pool thread untuk menangani klien

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);

            while (true) {
                pool.execute(new ClientHandler(serverSocket.accept())); // Menerima koneksi baru dan menangani dalam thread terpisah
            }
        } catch (IOException ex) {
            System.out.println("Error in the server: " + ex.getMessage());
        } finally {
            pool.shutdown();
        }
    }
}
