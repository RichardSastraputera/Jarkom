import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class ChatAppLoginClient {
    private JFrame frame;
    private JPanel loginPanel, registerPanel, chatPanel;
    private JTextField loginUsername, loginPassword;
    private JTextField registerPhone, registerUsername, registerPassword;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;

    public ChatAppLoginClient() {
        frame = new JFrame("Chat Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        loginPanel = new JPanel(new GridLayout(3, 2));
        registerPanel = new JPanel(new GridLayout(4, 2));
        chatPanel = new JPanel();

        setupLoginPanel();
        frame.setVisible(true);

        connectToServer();
    }

    private void connectToServer() {
        try {
            clientSocket = new Socket("127.0.0.1", 12345);
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Cannot connect to server", "Connection Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setupLoginPanel() {
        frame.getContentPane().removeAll();
        frame.getContentPane().add(loginPanel);

        loginPanel.add(new JLabel("Username:"));
        loginUsername = new JTextField();
        loginPanel.add(loginUsername);

        loginPanel.add(new JLabel("Password:"));
        loginPassword = new JPasswordField();
        loginPanel.add(loginPassword);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
        loginPanel.add(loginButton);

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setupRegisterPanel();
            }
        });
        loginPanel.add(registerButton);

        frame.revalidate();
        frame.repaint();
    }

    private void setupRegisterPanel() {
        frame.getContentPane().removeAll();
        frame.getContentPane().add(registerPanel);

        registerPanel.add(new JLabel("Phone:"));
        registerPhone = new JTextField();
        registerPanel.add(registerPhone);

        registerPanel.add(new JLabel("Username:"));
        registerUsername = new JTextField();
        registerPanel.add(registerUsername);

        registerPanel.add(new JLabel("Password:"));
        registerPassword = new JPasswordField();
        registerPanel.add(registerPassword);

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });
        registerPanel.add(registerButton);

        JButton backButton = new JButton("Back to Login");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setupLoginPanel();
            }
        });
        registerPanel.add(backButton);

        frame.revalidate();
        frame.repaint();
    }

    private void login() {
        String username = loginUsername.getText();
        String password = loginPassword.getText();
        out.println("LOGIN " + username + " " + password);
        try {
            String response = in.readLine();
            if ("LOGIN_SUCCESS".equals(response)) {
                setupChatPanel();
            } else if ("LOGIN_FAIL".equals(response)) {
                JOptionPane.showMessageDialog(frame, "Username and password do not match", "Login Failed",
                        JOptionPane.ERROR_MESSAGE);
            } else if ("USER_BLOCKED".equals(response)) {
                JOptionPane.showMessageDialog(frame,
                        "Your account has been blocked due to multiple failed login attempts", "Login Failed",
                        JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void register() {
        String phone = registerPhone.getText();
        String username = registerUsername.getText();
        String password = registerPassword.getText();
        out.println("REGISTER " + phone + " " + username + " " + password);
        try {
            String response = in.readLine();
            if ("REGISTER_SUCCESS".equals(response)) {
                JOptionPane.showMessageDialog(frame, "You can now login with your credentials", "Registration Success",
                        JOptionPane.INFORMATION_MESSAGE);
                setupLoginPanel();
            } else if ("REGISTER_FAIL".equals(response)) {
                JOptionPane.showMessageDialog(frame, "Phone number or username already exists", "Registration Failed",
                        JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setupChatPanel() {
        frame.getContentPane().removeAll();
        chatPanel.removeAll();
        frame.getContentPane().add(chatPanel);

        chatPanel.add(new JLabel("Welcome to the chat!"));

        frame.revalidate();
        frame.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ChatAppLoginClient();
            }
        });
    }
}
